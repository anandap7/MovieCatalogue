package com.anandap.moviecatalogue;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

import com.anandap.moviecatalogue.model.Movie;

public class DetailActivity extends AppCompatActivity {
    public static final String EXTRA_MOVIE = "extra_movie";
    private TextView tvYear, tvDirector, tvCast, tvOverview;
    private ImageView ivPoster;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        tvYear = findViewById(R.id.detail_year);
        tvDirector = findViewById(R.id.detail_director);
        tvCast = findViewById(R.id.detail_cast);
        tvOverview = findViewById(R.id.detail_overview);
        ivPoster = findViewById(R.id.detail_image);

        Movie movie = getIntent().getParcelableExtra(EXTRA_MOVIE);
        String sCast = "";
        for (String cast:movie.getCast()) {
            sCast += cast + "\n";
        }
        getSupportActionBar().setTitle(movie.getTitle());
        tvYear.setText(movie.getYear());
        tvDirector.setText(movie.getDirector());
        tvCast.setText(sCast);
        tvOverview.setText(movie.getOverview());
        ivPoster.setImageDrawable(getDrawable(movie.getPoster()));
    }
}
